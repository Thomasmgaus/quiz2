var searchData=
[
  ['college',['College',['../classCollege.html#adabaf4087355e83f9f7d39f1e1498b41',1,'College::College(std::string s)'],['../classCollege.html#ad007ad488e5a7ef986114080d0c8e101',1,'College::College(const College &amp;other)']]]
];
